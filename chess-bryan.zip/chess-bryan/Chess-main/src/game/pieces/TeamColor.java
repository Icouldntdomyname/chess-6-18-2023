package game.pieces;

public enum TeamColor {
    WHITE, BLACK;
}
